package com.example.raihan_dicoding

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
